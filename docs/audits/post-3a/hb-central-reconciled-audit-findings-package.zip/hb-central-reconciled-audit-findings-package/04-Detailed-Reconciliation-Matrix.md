# Detailed Reconciliation Matrix

## Objective
Show where the independent audits align, partially differ, or add emphasis without changing the final release position.

| Topic | Reconciled result | Alignment status | Notes |
|---|---|---|---|
| Packaged ownership collapse | Not present in artifact of record | Full alignment | Both audits conclude the supplied package is split correctly |
| Number of homepage web part registrations | Five | Full alignment | No disagreement |
| Unique packaged `entryModuleId` values | Five | Full alignment | No disagreement |
| Unique packaged primary script-resource keys/paths | Five / Five | Full alignment | No disagreement |
| Repo bundle declarations | Split by homepage surface | Full alignment | No disagreement |
| Owner-module runtime wiring | Dedicated per surface | Full alignment | No disagreement |
| Retired `dist/homepage.js` bridge pattern | Rejected/guarded | Full alignment | No disagreement |
| Validator substance | Meaningful and load-bearing | Full alignment | No disagreement |
| Heft-based packaging posture | Meaningful and current | Full alignment | No disagreement |
| Phase 3a technical closeout | Substantively complete | Full alignment | No disagreement |
| Need for additional remediation prompt package | Not justified | Full alignment | Both audits say remaining work is not code rescue |
| Release classification | Conditional Go | Full alignment | No disagreement |
| Hard Go blockers | Missing tenant-side proof | Full alignment | Same blockers in both audits |
| Placeholder metadata | Warning | Full alignment | Same general treatment |
| Documentation drift | Observation / cleanup item | Full alignment | Same general treatment |
| Package SHA / governance detail | Strengthened by one audit | Partial addition, not conflict | Adds operational rigor, not a changed conclusion |
| Acceptance checklist specificity | Strengthened by one audit | Partial addition, not conflict | Adds release clarity, not a changed conclusion |

## Summary of differences
There are no material contradictions.

The differences are limited to:
- level of operational detail
- strength of evidence-register formatting
- degree of emphasis on release-governance hygiene

## Final interpretation
The audits should be treated as mutually reinforcing, not competing.
