# Evidence and Provenance Register

## Objective
Record the evidence basis for the reconciled release position.

## Artifact of record
- File: `hb-central-homepage.sppkg`
- SHA-256: `7ce803d6b2533495cd4b279d8933daca5cfdb99fa4b4f68e213173270ff15c4c`

## Evidence categories

### 1. Package-structure evidence
Evidence used to support the reconciled finding that the package is not collapsed:
- five homepage web part registrations
- five unique packaged `entryModuleId` values
- five unique packaged primary script-resource keys
- five unique packaged primary script-resource paths
- no localhost/debug/workbench leakage in the artifact
- no unsupported feature-registration pattern identified in the release candidate

### 2. Repo-truth evidence
Evidence used to support the reconciled finding that the source materially matches the package:
- workspace organization under `apps/*` and `packages/*`
- homepage app located in `apps/hb-central-homepage`
- five separate SPFx bundle declarations in app config
- dedicated owner-module wiring per homepage surface
- root release scripts chaining packaging and validation
- app-local packaging scripts using Heft-based commands

### 3. Validator evidence
Evidence used to support the reconciled finding that the known defect class is guarded:
- source validator rejects retired shared-bridge import pattern
- source validator checks owner-module wiring
- package validator checks expected surface inventory
- package validator checks packaged ownership uniqueness
- package validator checks localhost/debug/workbench leakage
- package validator checks package-manifest relationship integrity

### 4. Phase 3a closeout evidence
Evidence used to support the reconciled finding that technical closeout is substantively complete:
- Phase 3a closeout docs broadly align with current package truth
- closeout narrative treats the earlier mismatch as provenance/artifact-selection related once the artifact of record validated as healthy
- current evidence does not justify reopening remediation

### 5. Deployment-gate gap evidence
Evidence used to support the reconciled classification of Conditional Go:
- no target-tenant App Catalog upload/deploy evidence in hand
- no live communication-site homepage render evidence in hand
- no post-deployment runtime smoke evidence in hand

## Provenance rule for final release
Before formal production release approval, the organization should record:
1. final source commit used to build the release candidate
2. final package version
3. final package hash
4. App Catalog upload/deploy result evidence
5. live page-render evidence
6. post-deployment smoke-check evidence

## Evidence interpretation rule
This reconciled package is strong enough to support **Conditional Go**.
It is not sufficient by itself to support **Hard Go**.
