# Risk, Issue, and Control Register

## Objective
Translate the reconciled audit results into a release-governance register that can be used by technical and operational reviewers.

## Classification model
- **Blocker**: should stop Hard Go approval
- **Warning**: does not stop Conditional Go by itself but must be managed
- **Observation**: useful context with low immediate deployment impact

| ID | Item | Classification | Current status | Why it matters | Mitigation / control |
|---|---|---|---|---|---|
| R-01 | Return of packaged ownership collapse | Warning | Currently mitigated | Reintroduction would reopen the core Phase 3a defect class | Keep source and package validators mandatory in release path |
| R-02 | Shared-chunk coupling across homepage surfaces | Warning | Reduced, not eliminated | One shared dependency issue could still affect multiple surfaces | Preserve split primary ownership and run post-deployment smoke checks |
| R-03 | Placeholder developer metadata in package | Warning | Open | Weakens release polish and provenance quality | Correct metadata before formal republish/release |
| R-04 | Package/version provenance ambiguity | Warning | Open until release baseline is frozen | Can create confusion during deployment/update validation | Record final source commit, package hash, and version policy |
| R-05 | No App Catalog deployment proof in target tenant | Blocker for Hard Go | Open | Local/package proof is not the same as tenant deployment proof | Upload candidate package and archive success evidence |
| R-06 | No live homepage render evidence in target tenant | Blocker for Hard Go | Open | Runtime/page-layout issues can appear only in the real environment | Capture screenshots/video and browser-console output |
| R-07 | Validator path bypass in future releases | Warning | Controlled only if discipline is maintained | Good controls fail if the release path is bypassed | Require scripted build/package/validate flow for every release |
| R-08 | Documentation terminology drift | Observation | Open | Can create governance confusion | Normalize terminology in next documentation pass |
| R-09 | Historical narratives implying active defect | Observation | Open | Can overstate current technical risk in meetings | Anchor future approvals to artifact hash and validator output |

## Control posture summary
### Controls that already exist
- source wiring validator
- package validator
- split bundle declarations
- dedicated owner-module wiring
- Heft-based packaging path
- package-level artifact inspection discipline

### Controls still requiring operational completion
- App Catalog upload/deploy evidence
- live render verification evidence
- browser-console smoke evidence
- final release provenance record

## Risk conclusion
No current risk item justifies reopening source/package remediation. The remaining meaningful risks are release-gate risks.
